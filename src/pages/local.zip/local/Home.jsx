import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { s } from './styles'
import Sidebar from './components/Sidebar'
import HomeLocal from './components/HomeLocal'
import BuscarMusicos from './components/BuscarMusicos'
import MiLocal from './components/MiLocal'
import MiCuenta from '../../components/MiCuenta'

const API = 'http://localhost:3000'

export default function Home() {
  const navigate = useNavigate()
  const usuario = JSON.parse(localStorage.getItem('usuario') || '{}')
  const perfil = usuario.perfil || {}
  const [tab, setTab] = useState('dashboard')
  const [musicos, setMusicos] = useState([])
  const [busqueda, setBusqueda] = useState('')

  const [pagos, setPagos] = useState([
    { id: 1, artista: 'Juan Gomez', fecha: '28 Oct 2024', hora: '22:00', monto: 2000, estado: 'retenido' },
    { id: 2, artista: 'Los Rockers', fecha: '04 Nov 2024', hora: '21:00', monto: 1400, estado: 'parcial' },
    { id: 3, artista: 'Café Indie', fecha: '18 Nov 2024', hora: '22:00', monto: 3000, estado: 'liberado' },
  ])

  useEffect(() => {
    if (tab === 'musicos') {
      axios.get(`${API}/musicos`)
        .then(res => setMusicos(res.data))
        .catch(console.error)
    }
  }, [tab])

  const colorEstado = (estado) => {
    if (estado === 'liberado') return '#22C55E'
    if (estado === 'parcial') return '#F59E0B'
    if (estado === 'cancelado') return '#EF4444'
    return '#A855F7'
  }

  const liberarPago = (id) => setPagos(pagos.map(p => p.id === id ? { ...p, estado: 'liberado' } : p))
  const cancelarPago = (id) => setPagos(pagos.map(p => p.id === id ? { ...p, estado: 'cancelado' } : p))
  const pagosPendientes = pagos.filter(p => p.estado !== 'liberado' && p.estado !== 'cancelado')

  const estrellas = (n) => {
    if (!n) return '☆☆☆☆☆'
    return '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n))
  }

  return (
    <div style={s.container}>
      <Sidebar
        tab={tab}
        setTab={setTab}
        usuario={usuario}
        perfil={perfil}
        navigate={navigate}
        cerrarSesion={cerrarSesion}
      />
      <div style={s.contenido}>
        {tab === 'dashboard' && (
          <HomeLocal
            usuario={usuario}
            pagos={pagos}
            pagosPendientes={pagosPendientes}
            colorEstado={colorEstado}
            liberarPago={liberarPago}
            cancelarPago={cancelarPago}
          />
        )}
        {tab === 'musicos' && (
          <BuscarMusicos
            busqueda={busqueda}
            setBusqueda={setBusqueda}
            musicos={musicos}
            estrellas={estrellas}
            navigate={navigate}
          />
        )}
        {tab === 'milocal' && (
          <MiLocal perfil={perfil} navigate={navigate}/>
        )}
        {tab === 'cuenta' && (
          <MiCuenta usuario={usuario} navigate={navigate}/>
        )}
      </div>
    </div>
  )
}